#!/usr/bin/env python3
"""Loopback-only Layer Studio → Spine bridge. No Modal or cloud credentials."""
import argparse
import io
import json
import re
import struct
import subprocess
import threading
import time
import uuid
import zipfile
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = 19464
ORIGINS = {'https://layer-studio-geniee.yoojin3412.chatgpt.site', 'http://127.0.0.1:5173'}
MAX_BYTES = 60 * 1024 * 1024
NAME = re.compile(r'^[A-Za-z0-9_-]{1,100}$')
SPINE = Path('/Applications/Spine.app/Contents/MacOS/Spine')
OUTPUT = Path(__file__).resolve().parent / 'Previews'


def unpack_preview(payload, output):
    """Validate the entire package before writing; never extract arbitrary ZIP paths."""
    if len(payload) > MAX_BYTES:
        raise ValueError('전송 파일이 60MB를 넘어요.')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        entries = archive.infolist()
        if not 3 <= len(entries) <= 302 or sum(i.file_size for i in entries) > MAX_BYTES:
            raise ValueError('파츠 수 또는 전체 파일 용량을 확인해주세요.')
        names = [i.filename for i in entries]
        if len(set(names)) != len(names) or 'preview.json' not in names or 'skeleton.json' not in names:
            raise ValueError('Spine 확인용 파일 형식이 아닙니다.')
        for i in entries:
            image = re.fullmatch(r'images/([A-Za-z0-9_-]{1,100})\.png', i.filename)
            if i.filename not in ('preview.json', 'skeleton.json') and not image:
                raise ValueError('허용하지 않는 파일 경로입니다.')
            if (i.external_attr >> 16) & 0o170000 == 0o120000 or i.flag_bits & 1:
                raise ValueError('링크 또는 암호화 파일은 지원하지 않습니다.')
        if archive.getinfo('preview.json').file_size > 8192 or archive.getinfo('skeleton.json').file_size > 8*1024*1024:
            raise ValueError('프로젝트 정보가 너무 큽니다.')
        meta = json.loads(archive.read('preview.json'))
        if meta.get('format') != 'layer-studio-spine-preview-v1':
            raise ValueError('지원되지 않는 확인용 파일입니다.')
        sk = json.loads(archive.read('skeleton.json'))
        if not isinstance(sk, dict) or sk.get('skeleton', {}).get('spine') != '4.0.64':
            raise ValueError('현재 연결 프로그램은 Spine 4.0.64 형식을 지원합니다.')
        if not isinstance(sk.get('bones'), list) or not 1 <= len(sk['bones']) <= 256:
            raise ValueError('뼈대 수를 확인해주세요.')
        if not isinstance(sk.get('slots'), list) or not 1 <= len(sk['slots']) <= 300:
            raise ValueError('파츠 수를 확인해주세요.')
        if not isinstance(sk.get('skins'), list) or len(sk['skins']) != 1:
            raise ValueError('기본 스킨 하나가 필요합니다.')
        images = {}
        total_pixels = 0
        for name in names:
            if not name.startswith('images/'):
                continue
            data = archive.read(name)
            if data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR' or len(data) < 33:
                raise ValueError('파츠는 PNG 파일이어야 합니다.')
            w, h = struct.unpack('>II', data[16:24])
            if not (0 < w <= 8192 and 0 < h <= 8192 and w*h <= 16_000_000):
                raise ValueError('파츠 이미지가 너무 큽니다.')
            total_pixels += w*h
            images[name] = data
        if total_pixels > 80_000_000:
            raise ValueError('전체 파츠 이미지가 너무 큽니다.')
        for attachments in sk['skins'][0].get('attachments', {}).values():
            for name, a in attachments.items():
                path = a.get('path', name)
                if a.get('type', 'region') not in ('region', 'mesh') or not NAME.fullmatch(path) or f'images/{path}.png' not in images:
                    raise ValueError('파츠 이미지 참조를 확인해주세요.')
        # The document cannot point Spine at any user-supplied filesystem location.
        sk['skeleton']['images'] = './images/'
        sk['skeleton'].pop('audio', None)
        for a in sk.get('animations', {}).values():
            if 'events' in a:
                raise ValueError('확인용 프로젝트는 오디오 이벤트를 지원하지 않습니다.')
        sk.pop('events', None)
        name = str(meta.get('name') or 'character')[:80]
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    folder = Path(output) / f'{stamp}-{uuid.uuid4().hex[:8]}'
    folder.mkdir(parents=True, exist_ok=False)
    (folder / 'images').mkdir()
    for path, data in images.items():
        (folder / path).write_bytes(data)
    (folder / 'skeleton.json').write_text(json.dumps(sk, ensure_ascii=False), encoding='utf-8')
    (folder / 'preview.json').write_text(json.dumps(meta, ensure_ascii=False), encoding='utf-8')
    return folder, name, sk


def convert_preview(payload, output=OUTPUT, open_editor=True):
    if not SPINE.is_file():
        raise ValueError('/Applications/Spine.app을 찾지 못했어요. Spine 설치 위치를 확인해주세요.')
    folder, name, sk = unpack_preview(payload, output)
    project = folder / 'preview.spine'
    # Each revision is a new project. Existing projects and unsaved editor work are never overwritten.
    result = subprocess.run([str(SPINE), '-u', '4.0.64', '-i', str(folder/'skeleton.json'),
                             '-o', str(project), '-r', 'Layer Studio Preview'],
                            capture_output=True, text=True, timeout=150)
    (folder / 'import.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    if result.returncode or not project.is_file():
        raise ValueError('Spine 변환에 실패했어요. 연결 프로그램의 Previews 폴더에서 import.log를 확인해주세요.')
    opened = False
    if open_editor:
        result = subprocess.run(['/usr/bin/open', '-a', '/Applications/Spine.app', str(project)],
                                capture_output=True, text=True, timeout=15)
        opened = result.returncode == 0
    return {'name': name, 'project': str(project), 'opened': opened,
            'bones': len(sk['bones']), 'parts': len(sk['slots']), 'animations': list(sk.get('animations', {}))}


class Bridge(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, converter=convert_preview):
        super().__init__(address, Handler)
        self.converter = converter
        self.jobs = {}
        self.lock = threading.Lock()
        self.busy = False
        self.stopped = threading.Event()

    def submit(self, payload):
        with self.lock:
            if self.busy:
                return None
            self.busy = True
            if len(self.jobs) >= 100:
                self.jobs.pop(next(iter(self.jobs)))
            job_id = uuid.uuid4().hex
            self.jobs[job_id] = {'status': 'working'}
        def work():
            try:
                value = {'status': 'done', **self.converter(payload)}
                print('Spine 확인용 파일 생성:', value['project'], flush=True)
            except Exception as e:
                message = str(e) if isinstance(e, ValueError) else '변환 중 오류가 발생했어요. 연결 프로그램을 확인해주세요.'
                value = {'status': 'failed', 'message': message}
                print('변환 실패:', type(e).__name__, message, flush=True)
            finally:
                with self.lock:
                    self.jobs[job_id] = value
                    self.busy = False
        threading.Thread(target=work, daemon=True).start()
        return job_id


    def watch_downloads(self, folder=None):
        """Fallback for browsers that block HTTPS→loopback. Only new, named preview ZIPs."""
        folder = Path(folder) if folder else Path.home() / 'Downloads'
        started = time.time()
        observed, handled = {}, set()
        pattern = re.compile(r'^LayerStudio-Preview-[a-f0-9-]{36}(?: \(\d+\))?\.zip$')
        print('자동 수신 폴더:', folder, flush=True)
        while not self.stopped.wait(1):
            if self.busy or not folder.is_dir():
                continue
            for path in folder.glob('LayerStudio-Preview-*.zip'):
                try:
                    if not pattern.fullmatch(path.name) or path.is_symlink():
                        continue
                    st = path.stat()
                    signature = (st.st_size, st.st_mtime_ns)
                    key = (str(path), signature)
                    if st.st_mtime < started or key in handled:
                        continue
                    if not 0 < st.st_size <= MAX_BYTES:
                        handled.add(key)
                        continue
                    if observed.get(path) != signature:
                        observed[path] = signature
                        continue
                    if self.submit(path.read_bytes()):
                        handled.add(key)
                        break
                except OSError:
                    continue


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def allowed(self):
        return (self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'
                and self.headers.get('Origin') in ORIGINS)

    def reply(self, status, data=None):
        body = json.dumps(data or {}, ensure_ascii=False).encode()
        self.send_response(status)
        if self.allowed():
            self.send_header('Access-Control-Allow-Origin', self.headers['Origin'])
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Layer-Studio')
            self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.reply(204 if self.allowed() else 403)

    def guard(self):
        if not self.allowed() or self.headers.get('X-Layer-Studio') != 'spine-preview-v1':
            self.reply(403, {'message': '허용된 Layer Studio 웹앱에서만 연결할 수 있습니다.'})
            return False
        return True

    def do_GET(self):
        if not self.guard():
            return
        if self.path == '/health':
            self.reply(200, {'service': 'layer-studio-spine-bridge', 'version': 1,
                             'spineFound': SPINE.is_file(), 'busy': self.server.busy})
        elif re.fullmatch('/jobs/[a-f0-9]{32}', self.path):
            with self.server.lock:
                job = self.server.jobs.get(self.path.rsplit('/', 1)[1])
            self.reply(200 if job else 404, job or {'message': '확인 작업을 찾지 못했어요.'})
        else:
            self.reply(404)

    def do_POST(self):
        if not self.guard():
            return
        if self.path != '/preview':
            self.reply(404)
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = 0
        if not 0 < length <= MAX_BYTES or self.headers.get('Content-Type') != 'application/zip':
            self.reply(400, {'message': '60MB 이하의 Spine 확인용 ZIP이 필요해요.'})
            return
        self.connection.settimeout(30)
        try:
            payload = self.rfile.read(length)
            if len(payload) != length:
                raise ValueError()
        except (OSError, ValueError):
            self.reply(400, {'message': '파일 수신이 완료되지 않았어요.'})
            return
        job = self.server.submit(payload)
        self.reply(202 if job else 409, {'job_id': job} if job else {'message': '이전 Spine 변환이 끝날 때까지 기다려주세요.'})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--convert', type=Path)
    parser.add_argument('--no-open', action='store_true')
    parser.add_argument('--output', type=Path, default=OUTPUT)
    args = parser.parse_args()
    if args.convert:
        print(json.dumps(convert_preview(args.convert.read_bytes(), args.output, not args.no_open), ensure_ascii=False))
        return
    try:
        server = Bridge(('127.0.0.1', PORT))
    except OSError:
        print('연결 프로그램이 이미 실행 중이거나 19464 포트를 사용할 수 없어요.')
        return
    threading.Thread(target=server.watch_downloads, daemon=True).start()
    print('Layer Studio → Spine 연결 프로그램\n웹의 관절 편집 화면에서 「Spine에서 확인」을 누르세요.\n이 창을 열어두세요. 종료: Control+C\n확인용 파일: ' + str(OUTPUT), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n연결 프로그램을 종료합니다.')
    finally:
        server.stopped.set()
        server.server_close()

if __name__ == '__main__':
    main()
