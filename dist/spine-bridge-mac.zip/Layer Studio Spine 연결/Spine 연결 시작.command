#!/bin/zsh
cd -- "$(dirname -- "$0")"
if [[ -x ../.venv/bin/python ]]; then
  ../.venv/bin/python bridge.py
elif command -v python3 >/dev/null 2>&1; then
  python3 bridge.py
else
  echo 'Python 3이 필요합니다. Codex에서 연결 프로그램 실행을 요청해주세요.'
fi
printf '\n종료하려면 Enter를 누르세요. '
read -r
